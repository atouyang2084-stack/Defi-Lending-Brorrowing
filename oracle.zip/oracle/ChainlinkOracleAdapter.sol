{\rtf1\adeflang1025\ansi\ansicpg936\uc2\adeff31507\deff0\stshfdbch31505\stshfloch31506\stshfhich31506\stshfbi31507\deflang1033\deflangfe2052\themelang1033\themelangfe2052\themelangcs0{\fonttbl{\f0\fbidi \froman\fcharset0\fprq2{\*\panose 02020603050405020304}Times New Roman;}{\f34\fbidi \froman\fcharset0\fprq2{\*\panose 02040503050406030204}Cambria Math;}
{\f36\fbidi \fnil\fcharset134\fprq2{\*\panose 02010600030101010101}\'b5\'c8\'cf\'df{\*\falt DengXian};}{\f51\fbidi \fnil\fcharset134\fprq2{\*\panose 02010600030101010101}@\'b5\'c8\'cf\'df;}
{\flomajor\f31500\fbidi \froman\fcharset0\fprq2{\*\panose 02020603050405020304}Times New Roman;}{\fdbmajor\f31501\fbidi \fnil\fcharset134\fprq2{\*\panose 02010600030101010101}\'b5\'c8\'cf\'df Light;}
{\fhimajor\f31502\fbidi \fnil\fcharset134\fprq2{\*\panose 02010600030101010101}\'b5\'c8\'cf\'df Light;}{\fbimajor\f31503\fbidi \froman\fcharset0\fprq2{\*\panose 02020603050405020304}Times New Roman;}
{\flominor\f31504\fbidi \froman\fcharset0\fprq2{\*\panose 02020603050405020304}Times New Roman;}{\fdbminor\f31505\fbidi \fnil\fcharset134\fprq2{\*\panose 02010600030101010101}\'b5\'c8\'cf\'df{\*\falt DengXian};}
{\fhiminor\f31506\fbidi \fnil\fcharset134\fprq2{\*\panose 02010600030101010101}\'b5\'c8\'cf\'df{\*\falt DengXian};}{\fbiminor\f31507\fbidi \froman\fcharset0\fprq2{\*\panose 02020603050405020304}Times New Roman;}
{\f52\fbidi \froman\fcharset238\fprq2 Times New Roman CE;}{\f53\fbidi \froman\fcharset204\fprq2 Times New Roman Cyr;}{\f55\fbidi \froman\fcharset161\fprq2 Times New Roman Greek;}{\f56\fbidi \froman\fcharset162\fprq2 Times New Roman Tur;}
{\f57\fbidi \froman\fcharset177\fprq2 Times New Roman (Hebrew);}{\f58\fbidi \froman\fcharset178\fprq2 Times New Roman (Arabic);}{\f59\fbidi \froman\fcharset186\fprq2 Times New Roman Baltic;}
{\f60\fbidi \froman\fcharset163\fprq2 Times New Roman (Vietnamese);}{\f392\fbidi \froman\fcharset238\fprq2 Cambria Math CE;}{\f393\fbidi \froman\fcharset204\fprq2 Cambria Math Cyr;}{\f395\fbidi \froman\fcharset161\fprq2 Cambria Math Greek;}
{\f396\fbidi \froman\fcharset162\fprq2 Cambria Math Tur;}{\f399\fbidi \froman\fcharset186\fprq2 Cambria Math Baltic;}{\f400\fbidi \froman\fcharset163\fprq2 Cambria Math (Vietnamese);}{\f414\fbidi \fnil\fcharset0\fprq2 DengXian Western{\*\falt DengXian};}
{\f412\fbidi \fnil\fcharset238\fprq2 DengXian CE{\*\falt DengXian};}{\f413\fbidi \fnil\fcharset204\fprq2 DengXian Cyr{\*\falt DengXian};}{\f415\fbidi \fnil\fcharset161\fprq2 DengXian Greek{\*\falt DengXian};}
{\f564\fbidi \fnil\fcharset0\fprq2 @DengXian Western;}{\f562\fbidi \fnil\fcharset238\fprq2 @DengXian CE;}{\f563\fbidi \fnil\fcharset204\fprq2 @DengXian Cyr;}{\f565\fbidi \fnil\fcharset161\fprq2 @DengXian Greek;}
{\flomajor\f31508\fbidi \froman\fcharset238\fprq2 Times New Roman CE;}{\flomajor\f31509\fbidi \froman\fcharset204\fprq2 Times New Roman Cyr;}{\flomajor\f31511\fbidi \froman\fcharset161\fprq2 Times New Roman Greek;}
{\flomajor\f31512\fbidi \froman\fcharset162\fprq2 Times New Roman Tur;}{\flomajor\f31513\fbidi \froman\fcharset177\fprq2 Times New Roman (Hebrew);}{\flomajor\f31514\fbidi \froman\fcharset178\fprq2 Times New Roman (Arabic);}
{\flomajor\f31515\fbidi \froman\fcharset186\fprq2 Times New Roman Baltic;}{\flomajor\f31516\fbidi \froman\fcharset163\fprq2 Times New Roman (Vietnamese);}{\fdbmajor\f31520\fbidi \fnil\fcharset0\fprq2 DengXian Light Western;}
{\fdbmajor\f31518\fbidi \fnil\fcharset238\fprq2 DengXian Light CE;}{\fdbmajor\f31519\fbidi \fnil\fcharset204\fprq2 DengXian Light Cyr;}{\fdbmajor\f31521\fbidi \fnil\fcharset161\fprq2 DengXian Light Greek;}
{\fhimajor\f31530\fbidi \fnil\fcharset0\fprq2 DengXian Light Western;}{\fhimajor\f31528\fbidi \fnil\fcharset238\fprq2 DengXian Light CE;}{\fhimajor\f31529\fbidi \fnil\fcharset204\fprq2 DengXian Light Cyr;}
{\fhimajor\f31531\fbidi \fnil\fcharset161\fprq2 DengXian Light Greek;}{\fbimajor\f31538\fbidi \froman\fcharset238\fprq2 Times New Roman CE;}{\fbimajor\f31539\fbidi \froman\fcharset204\fprq2 Times New Roman Cyr;}
{\fbimajor\f31541\fbidi \froman\fcharset161\fprq2 Times New Roman Greek;}{\fbimajor\f31542\fbidi \froman\fcharset162\fprq2 Times New Roman Tur;}{\fbimajor\f31543\fbidi \froman\fcharset177\fprq2 Times New Roman (Hebrew);}
{\fbimajor\f31544\fbidi \froman\fcharset178\fprq2 Times New Roman (Arabic);}{\fbimajor\f31545\fbidi \froman\fcharset186\fprq2 Times New Roman Baltic;}{\fbimajor\f31546\fbidi \froman\fcharset163\fprq2 Times New Roman (Vietnamese);}
{\flominor\f31548\fbidi \froman\fcharset238\fprq2 Times New Roman CE;}{\flominor\f31549\fbidi \froman\fcharset204\fprq2 Times New Roman Cyr;}{\flominor\f31551\fbidi \froman\fcharset161\fprq2 Times New Roman Greek;}
{\flominor\f31552\fbidi \froman\fcharset162\fprq2 Times New Roman Tur;}{\flominor\f31553\fbidi \froman\fcharset177\fprq2 Times New Roman (Hebrew);}{\flominor\f31554\fbidi \froman\fcharset178\fprq2 Times New Roman (Arabic);}
{\flominor\f31555\fbidi \froman\fcharset186\fprq2 Times New Roman Baltic;}{\flominor\f31556\fbidi \froman\fcharset163\fprq2 Times New Roman (Vietnamese);}{\fdbminor\f31560\fbidi \fnil\fcharset0\fprq2 DengXian Western{\*\falt DengXian};}
{\fdbminor\f31558\fbidi \fnil\fcharset238\fprq2 DengXian CE{\*\falt DengXian};}{\fdbminor\f31559\fbidi \fnil\fcharset204\fprq2 DengXian Cyr{\*\falt DengXian};}{\fdbminor\f31561\fbidi \fnil\fcharset161\fprq2 DengXian Greek{\*\falt DengXian};}
{\fhiminor\f31570\fbidi \fnil\fcharset0\fprq2 DengXian Western{\*\falt DengXian};}{\fhiminor\f31568\fbidi \fnil\fcharset238\fprq2 DengXian CE{\*\falt DengXian};}{\fhiminor\f31569\fbidi \fnil\fcharset204\fprq2 DengXian Cyr{\*\falt DengXian};}
{\fhiminor\f31571\fbidi \fnil\fcharset161\fprq2 DengXian Greek{\*\falt DengXian};}{\fbiminor\f31578\fbidi \froman\fcharset238\fprq2 Times New Roman CE;}{\fbiminor\f31579\fbidi \froman\fcharset204\fprq2 Times New Roman Cyr;}
{\fbiminor\f31581\fbidi \froman\fcharset161\fprq2 Times New Roman Greek;}{\fbiminor\f31582\fbidi \froman\fcharset162\fprq2 Times New Roman Tur;}{\fbiminor\f31583\fbidi \froman\fcharset177\fprq2 Times New Roman (Hebrew);}
{\fbiminor\f31584\fbidi \froman\fcharset178\fprq2 Times New Roman (Arabic);}{\fbiminor\f31585\fbidi \froman\fcharset186\fprq2 Times New Roman Baltic;}{\fbiminor\f31586\fbidi \froman\fcharset163\fprq2 Times New Roman (Vietnamese);}}
{\colortbl;\red0\green0\blue0;\red0\green0\blue255;\red0\green255\blue255;\red0\green255\blue0;\red255\green0\blue255;\red255\green0\blue0;\red255\green255\blue0;\red255\green255\blue255;\red0\green0\blue128;\red0\green128\blue128;\red0\green128\blue0;
\red128\green0\blue128;\red128\green0\blue0;\red128\green128\blue0;\red128\green128\blue128;\red192\green192\blue192;\red0\green0\blue0;\red0\green0\blue0;}{\*\defchp \fs22\kerning2\loch\af31506\hich\af31506\dbch\af31505 }{\*\defpap 
\ql \li0\ri0\sa160\sl278\slmult1\widctlpar\wrapdefault\aspalpha\aspnum\faauto\adjustright\rin0\lin0\itap0 }\noqfpromote {\stylesheet{\ql \li0\ri0\sa160\sl278\slmult1\nowidctlpar\wrapdefault\aspalpha\aspnum\faauto\adjustright\rin0\lin0\itap0 \rtlch\fcs1 
\af31507\afs24\alang1025 \ltrch\fcs0 \fs22\lang1033\langfe2052\kerning2\loch\f31506\hich\af31506\dbch\af31505\cgrid\langnp1033\langfenp2052 \snext0 \sqformat \spriority0 Normal;}{\*\cs10 \additive \sunhideused \spriority1 Default Paragraph Font;}{\*
\ts11\tsrowd\trftsWidthB3\trpaddl108\trpaddr108\trpaddfl3\trpaddft3\trpaddfb3\trpaddfr3\tblind0\tblindtype3\tsvertalt\tsbrdrt\tsbrdrl\tsbrdrb\tsbrdrr\tsbrdrdgl\tsbrdrdgr\tsbrdrh\tsbrdrv \ql \li0\ri0\sa160\sl278\slmult1
\widctlpar\wrapdefault\aspalpha\aspnum\faauto\adjustright\rin0\lin0\itap0 \rtlch\fcs1 \af31507\afs24\alang1025 \ltrch\fcs0 \fs22\lang1033\langfe2052\kerning2\loch\f31506\hich\af31506\dbch\af31505\cgrid\langnp1033\langfenp2052 
\snext11 \ssemihidden \sunhideused Normal Table;}{\s15\qc \li0\ri0\sa160\nowidctlpar\tqc\tx4153\tqr\tx8306\wrapdefault\aspalpha\aspnum\faauto\nosnaplinegrid\adjustright\rin0\lin0\itap0 \rtlch\fcs1 \af31507\afs18\alang1025 \ltrch\fcs0 
\fs18\lang1033\langfe2052\kerning2\loch\f31506\hich\af31506\dbch\af31505\cgrid\langnp1033\langfenp2052 \sbasedon0 \snext15 \slink16 \sunhideused \styrsid8660178 header;}{\*\cs16 \additive \rtlch\fcs1 \af0\afs18 \ltrch\fcs0 \fs18 
\sbasedon10 \slink15 \styrsid8660178 \'d2\'b3\'c3\'bc \'d7\'d6\'b7\'fb;}{\s17\ql \li0\ri0\sa160\nowidctlpar\tqc\tx4153\tqr\tx8306\wrapdefault\aspalpha\aspnum\faauto\nosnaplinegrid\adjustright\rin0\lin0\itap0 \rtlch\fcs1 \af31507\afs18\alang1025 
\ltrch\fcs0 \fs18\lang1033\langfe2052\kerning2\loch\f31506\hich\af31506\dbch\af31505\cgrid\langnp1033\langfenp2052 \sbasedon0 \snext17 \slink18 \sunhideused \styrsid8660178 footer;}{\*\cs18 \additive \rtlch\fcs1 \af0\afs18 \ltrch\fcs0 \fs18 
\sbasedon10 \slink17 \styrsid8660178 \'d2\'b3\'bd\'c5 \'d7\'d6\'b7\'fb;}}{\*\rsidtbl \rsid8660178\rsid8981739\rsid15750930}{\mmathPr\mmathFont34\mbrkBin0\mbrkBinSub0\msmallFrac0\mdispDef1\mlMargin0\mrMargin0\mdefJc1\mwrapIndent1440\mintLim0\mnaryLim1}
{\info{\operator \'dc\'b2\'b5\'c2 \'c2\'ed}{\creatim\yr2026\mo4\dy22\hr20\min43}{\revtim\yr2026\mo4\dy22\hr20\min43}{\version2}{\edmins0}{\nofpages3}{\nofwords340}{\nofchars1941}{\nofcharsws2277}{\vern127}}{\*\xmlnstbl {\xmlns1 http://schemas.microsoft.co
m/office/word/2003/wordml}}\paperw12240\paperh15840\margl1800\margr1800\margt1440\margb1440\gutter0\ltrsect 
\ftnbj\aenddoc\trackmoves0\trackformatting1\donotembedsysfont0\relyonvml0\donotembedlingdata1\grfdocevents0\validatexml0\showplaceholdtext0\ignoremixedcontent0\saveinvalidxml0\showxmlerrors0\horzdoc\dghspace120\dgvspace120\dghorigin1701\dgvorigin1984
\dghshow0\dgvshow3\jcompress\viewkind1\viewscale100\rsidroot8660178 \fet0{\*\wgrffmtfilter 2450}\ilfomacatclnup0{\*\ftnsep \ltrpar \pard\plain \ltrpar\ql \li0\ri0\nowidctlpar\wrapdefault\aspalpha\aspnum\faauto\adjustright\rin0\lin0\itap0\pararsid8660178 
\rtlch\fcs1 \af31507\afs24\alang1025 \ltrch\fcs0 \fs22\lang1033\langfe2052\kerning2\loch\af31506\hich\af31506\dbch\af31505\cgrid\langnp1033\langfenp2052 {\rtlch\fcs1 \af31507 \ltrch\fcs0 \insrsid15750930 \chftnsep }{\rtlch\fcs1 \af31507 \ltrch\fcs0 
\insrsid15750930 
\par }}{\*\ftnsepc \ltrpar \pard\plain \ltrpar\ql \li0\ri0\nowidctlpar\wrapdefault\aspalpha\aspnum\faauto\adjustright\rin0\lin0\itap0\pararsid8660178 \rtlch\fcs1 \af31507\afs24\alang1025 \ltrch\fcs0 
\fs22\lang1033\langfe2052\kerning2\loch\af31506\hich\af31506\dbch\af31505\cgrid\langnp1033\langfenp2052 {\rtlch\fcs1 \af31507 \ltrch\fcs0 \insrsid15750930 \chftnsepc }{\rtlch\fcs1 \af31507 \ltrch\fcs0 \insrsid15750930 
\par }}{\*\aftnsep \ltrpar \pard\plain \ltrpar\ql \li0\ri0\nowidctlpar\wrapdefault\aspalpha\aspnum\faauto\adjustright\rin0\lin0\itap0\pararsid8660178 \rtlch\fcs1 \af31507\afs24\alang1025 \ltrch\fcs0 
\fs22\lang1033\langfe2052\kerning2\loch\af31506\hich\af31506\dbch\af31505\cgrid\langnp1033\langfenp2052 {\rtlch\fcs1 \af31507 \ltrch\fcs0 \insrsid15750930 \chftnsep }{\rtlch\fcs1 \af31507 \ltrch\fcs0 \insrsid15750930 
\par }}{\*\aftnsepc \ltrpar \pard\plain \ltrpar\ql \li0\ri0\nowidctlpar\wrapdefault\aspalpha\aspnum\faauto\adjustright\rin0\lin0\itap0\pararsid8660178 \rtlch\fcs1 \af31507\afs24\alang1025 \ltrch\fcs0 
\fs22\lang1033\langfe2052\kerning2\loch\af31506\hich\af31506\dbch\af31505\cgrid\langnp1033\langfenp2052 {\rtlch\fcs1 \af31507 \ltrch\fcs0 \insrsid15750930 \chftnsepc }{\rtlch\fcs1 \af31507 \ltrch\fcs0 \insrsid15750930 
\par }}\ltrpar \sectd \ltrsect\linex0\sectdefaultcl\sftnbj {\*\pnseclvl1\pnucrm\pnstart1\pnindent720\pnhang {\pntxta \dbch .}}{\*\pnseclvl2\pnucltr\pnstart1\pnindent720\pnhang {\pntxta \dbch .}}{\*\pnseclvl3\pndec\pnstart1\pnindent720\pnhang {\pntxta \dbch .}}
{\*\pnseclvl4\pnlcltr\pnstart1\pnindent720\pnhang {\pntxta \dbch )}}{\*\pnseclvl5\pndec\pnstart1\pnindent720\pnhang {\pntxtb \dbch (}{\pntxta \dbch )}}{\*\pnseclvl6\pnlcltr\pnstart1\pnindent720\pnhang {\pntxtb \dbch (}{\pntxta \dbch )}}{\*\pnseclvl7
\pnlcrm\pnstart1\pnindent720\pnhang {\pntxtb \dbch (}{\pntxta \dbch )}}{\*\pnseclvl8\pnlcltr\pnstart1\pnindent720\pnhang {\pntxtb \dbch (}{\pntxta \dbch )}}{\*\pnseclvl9\pnlcrm\pnstart1\pnindent720\pnhang {\pntxtb \dbch (}{\pntxta \dbch )}}
\pard\plain \ltrpar\ql \li0\ri0\sa160\sl278\slmult1\nowidctlpar\wrapdefault\aspalpha\aspnum\faauto\adjustright\rin0\lin0\itap0\pararsid8660178 \rtlch\fcs1 \af31507\afs24\alang1025 \ltrch\fcs0 
\fs22\lang1033\langfe2052\kerning2\loch\af31506\hich\af31506\dbch\af31505\cgrid\langnp1033\langfenp2052 {\rtlch\fcs1 \af31507 \ltrch\fcs0 \insrsid8660178\charrsid8660178 \hich\af31506\dbch\af31505\loch\f31506 // SPDX-License-Identifier: MIT
\par \hich\af31506\dbch\af31505\loch\f31506 pragma solidity ^0.8.20;
\par 
\par \hich\af31506\dbch\af31505\loch\f31506 /**
\par \hich\af31506\dbch\af31505\loch\f31506  \hich\af31506\dbch\af31505\loch\f31506 * @title AggregatorV3Interface
\par \hich\af31506\dbch\af31505\loch\f31506  * @notice }{\rtlch\fcs1 \af31507 \ltrch\fcs0 \insrsid8660178\charrsid8660178 \loch\af31506\hich\af31506\dbch\f31505 \'d5\'e2\'ca\'c7}{\rtlch\fcs1 \af31507 \ltrch\fcs0 \insrsid8660178\charrsid8660178 
\hich\af31506\dbch\af31505\loch\f31506  Chainlink }{\rtlch\fcs1 \af31507 \ltrch\fcs0 \insrsid8660178\charrsid8660178 \loch\af31506\hich\af31506\dbch\f31505 \'b9\'d9\'b7\'bd\'cc\'e1\'b9\'a9\'b5\'c4\'b1\'ea\'d7\'bc\'bd\'d3\'bf\'da\'a3\'ac\'d3\'c3\'d3\'da
\'b6\'c1\'c8\'a1\'bc\'db\'b8\'f1\'ca\'fd\'be\'dd}{\rtlch\fcs1 \af31507 \ltrch\fcs0 \insrsid8660178\charrsid8660178 
\par \hich\af31506\dbch\af31505\loch\f31506  */
\par \hich\af31506\dbch\af31505\loch\f31506 interface AggregatorV3Interface \{
\par \hich\af31506\dbch\af31505\loch\f31506     function decimals() external view returns (uint8);
\par \hich\af31506\dbch\af31505\loch\f31506     function latestRoundData()
\par \hich\af31506\dbch\af31505\loch\f31506         external
\par \hich\af31506\dbch\af31505\loch\f31506         view
\par \hich\af31506\dbch\af31505\loch\f31506         returns (uint80 roundId, int256 answer, uint256 startedAt, uint256 updatedAt, uint80 answeredInRound);
\par \}
\par 
\par \hich\af31506\dbch\af31505\loch\f31506 /**
\par \hich\af31506\dbch\af31505\loch\f31506  * @title ChainlinkOracleAdapter
\par \hich\af31506\dbch\af31505\loch\f31506  * @notice }{\rtlch\fcs1 \af31507 \ltrch\fcs0 \insrsid8660178\charrsid8660178 \loch\af31506\hich\af31506\dbch\f31505 \'d2\'bb\'b8\'f6\'d3\'c3\'d3\'da\'b0\'b2\'c8\'ab\'bb\'f1\'c8\'a1\'b2\'a2\'b1\'ea\'d7\'bc\'bb\'af}{
\rtlch\fcs1 \af31507 \ltrch\fcs0 \insrsid8660178\charrsid8660178 \hich\af31506\dbch\af31505\loch\f31506  Chainlink }{\rtlch\fcs1 \af31507 \ltrch\fcs0 \insrsid8660178\charrsid8660178 \loch\af31506\hich\af31506\dbch\f31505 \'bc\'db\'b8\'f1\'b5\'c4\'bf\'e2}{
\rtlch\fcs1 \af31507 \ltrch\fcs0 \insrsid8660178\charrsid8660178 
\par \hich\af31506\dbch\af31505\loch\f31506  */
\par \hich\af31506\dbch\af31505\loch\f31506 library ChainlinkOracleAdapter \{
\par \hich\af31506\dbch\af31505\loch\f31506     // WAD }{\rtlch\fcs1 \af31507 \ltrch\fcs0 \insrsid8660178\charrsid8660178 \loch\af31506\hich\af31506\dbch\f31505 \'ca\'c7}{\rtlch\fcs1 \af31507 \ltrch\fcs0 \insrsid8660178\charrsid8660178 
\hich\af31506\dbch\af31505\loch\f31506  DeFi }{\rtlch\fcs1 \af31507 \ltrch\fcs0 \insrsid8660178\charrsid8660178 \loch\af31506\hich\af31506\dbch\f31505 \'d6\'d0\'b3\'a3\'d3\'c3\'b5\'c4\'be\'ab\'b6\'c8\'b5\'a5\'ce\'bb\'a3\'ac\'b4\'fa\'b1\'ed}{\rtlch\fcs1 
\af31507 \ltrch\fcs0 \insrsid8660178\charrsid8660178 \hich\af31506\dbch\af31505\loch\f31506  1e18 (18}{\rtlch\fcs1 \af31507 \ltrch\fcs0 \insrsid8660178\charrsid8660178 \loch\af31506\hich\af31506\dbch\f31505 \'ce\'bb\'d0\'a1\'ca\'fd}{\rtlch\fcs1 \af31507 
\ltrch\fcs0 \insrsid8660178\charrsid8660178 \hich\af31506\dbch\af31505\loch\f31506 )
\par \hich\af31506\dbch\af31505\loch\f31506     uint256 internal constant WAD = 1e18;
\par 
\par \hich\af31506\dbch\af31505\loch\f31506     // --- }{\rtlch\fcs1 \af31507 \ltrch\fcs0 \insrsid8660178\charrsid8660178 \loch\af31506\hich\af31506\dbch\f31505 \'d7\'d4\'b6\'a8\'d2\'e5\'b4\'ed\'ce\'f3\'b6\'a8\'d2\'e5}{\rtlch\fcs1 \af31507 \ltrch\fcs0 
\insrsid8660178\charrsid8660178 \hich\af31506\dbch\af31505\loch\f31506  (}{\rtlch\fcs1 \af31507 \ltrch\fcs0 \insrsid8660178\charrsid8660178 \loch\af31506\hich\af31506\dbch\f31505 \'b1\'c8}{\rtlch\fcs1 \af31507 \ltrch\fcs0 \insrsid8660178\charrsid8660178 
\hich\af31506\dbch\af31505\loch\f31506  require }{\rtlch\fcs1 \af31507 \ltrch\fcs0 \insrsid8660178\charrsid8660178 \loch\af31506\hich\af31506\dbch\f31505 \'b8\'fc\'ca\'a1}{\rtlch\fcs1 \af31507 \ltrch\fcs0 \insrsid8660178\charrsid8660178 
\hich\af31506\dbch\af31505\loch\f31506  Gas) ---
\par \hich\af31506\dbch\af31505\loch\f31506     error OracleFeedNotSet();      // }{\rtlch\fcs1 \af31507 \ltrch\fcs0 \insrsid8660178\charrsid8660178 \loch\af31506\hich\af31506\dbch\f31505 \'b4\'ed\'ce\'f3\'a3\'ba\'ce\'b4\'c9\'e8\'d6\'c3\'d4\'a4\'d1\'d4\'bb\'fa
\'b5\'d8\'d6\'b7}{\rtlch\fcs1 \af31507 \ltrch\fcs0 \insrsid8660178\charrsid8660178 
\par \hich\af31506\dbch\af31505\loch\f31506     error OraclePriceInvalid();    // }{\rtlch\fcs1 \af31507 \ltrch\fcs0 \insrsid8660178\charrsid8660178 \loch\af31506\hich\af31506\dbch\f31505 \'b4\'ed\'ce\'f3\'a3\'ba\'bb\'f1\'c8\'a1\'b5\'bd\'b5\'c4\'bc\'db\'b8\'f1
\'ce\'de\'d0\'a7}{\rtlch\fcs1 \af31507 \ltrch\fcs0 \insrsid8660178\charrsid8660178 \hich\af31506\dbch\af31505\loch\f31506  (}{\rtlch\fcs1 \af31507 \ltrch\fcs0 \insrsid8660178\charrsid8660178 \loch\af31506\hich\af31506\dbch\f31505 \'d0\'a1\'d3\'da\'b5\'c8
\'d3\'da}{\rtlch\fcs1 \af31507 \ltrch\fcs0 \insrsid8660178\charrsid8660178 \hich\af31506\dbch\af31505\loch\f31506 0)
\par \hich\af31506\dbch\af31505\loch\f31506     error OraclePriceStale();      // }{\rtlch\fcs1 \af31507 \ltrch\fcs0 \insrsid8660178\charrsid8660178 \loch\af31506\hich\af31506\dbch\f31505 \'b4\'ed\'ce\'f3\'a3\'ba\'bc\'db\'b8\'f1\'ca\'fd\'be\'dd\'b9\'fd\'ca\'b1
}{\rtlch\fcs1 \af31507 \ltrch\fcs0 \insrsid8660178\charrsid8660178 \hich\af31506\dbch\af31505\loch\f31506  (}{\rtlch\fcs1 \af31507 \ltrch\fcs0 \insrsid8660178\charrsid8660178 \loch\af31506\hich\af31506\dbch\f31505 \'b3\'ac\'b9\'fd\'d7\'ee\'b4\'f3\'d4\'ca
\'d0\'ed\'ca\'b1\'bc\'e4}{\rtlch\fcs1 \af31507 \ltrch\fcs0 \insrsid8660178\charrsid8660178 \hich\af31506\dbch\af31505\loch\f31506 )
\par 
\par \hich\af31506\dbch\af31505\loch\f31506     /**
\par \hich\af31506\dbch\af31505\loch\f31506      * @notice }{\rtlch\fcs1 \af31507 \ltrch\fcs0 \insrsid8660178\charrsid8660178 \loch\af31506\hich\af31506\dbch\f31505 \'b6\'c1\'c8\'a1}{\rtlch\fcs1 \af31507 \ltrch\fcs0 \insrsid8660178\charrsid8660178 
\hich\af31506\dbch\af31505\loch\f31506  Chainlink }{\rtlch\fcs1 \af31507 \ltrch\fcs0 \insrsid8660178\charrsid8660178 \loch\af31506\hich\af31506\dbch\f31505 \'bc\'db\'b8\'f1\'b2\'a2\'bd\'ab\'c6\'e4\'b1\'ea\'d7\'bc\'bb\'af\'ce\'aa}{\rtlch\fcs1 \af31507 
\ltrch\fcs0 \insrsid8660178\charrsid8660178 \hich\af31506\dbch\af31505\loch\f31506  1e18 }{\rtlch\fcs1 \af31507 \ltrch\fcs0 \insrsid8660178\charrsid8660178 \loch\af31506\hich\af31506\dbch\f31505 \'be\'ab\'b6\'c8}{\rtlch\fcs1 \af31507 \ltrch\fcs0 
\insrsid8660178\charrsid8660178 
\par \hich\af31506\dbch\af31505\loch\f31506      * @param feed Chainlink }{\rtlch\fcs1 \af31507 \ltrch\fcs0 \insrsid8660178\charrsid8660178 \loch\af31506\hich\af31506\dbch\f31505 \'be\'db\'ba\'cf\'c6\'f7\'ba\'cf\'d4\'bc\'b5\'c4\'b5\'d8\'d6\'b7}{\rtlch\fcs1 
\af31507 \ltrch\fcs0 \insrsid8660178\charrsid8660178 \hich\af31506\dbch\af31505\loch\f31506  (}{\rtlch\fcs1 \af31507 \ltrch\fcs0 \insrsid8660178\charrsid8660178 \loch\af31506\hich\af31506\dbch\f31505 \'c0\'fd\'c8\'e7}{\rtlch\fcs1 \af31507 \ltrch\fcs0 
\insrsid8660178\charrsid8660178 \hich\af31506\dbch\af31505\loch\f31506  ETH/USD }{\rtlch\fcs1 \af31507 \ltrch\fcs0 \insrsid8660178\charrsid8660178 \loch\af31506\hich\af31506\dbch\f31505 \'b5\'c4}{\rtlch\fcs1 \af31507 \ltrch\fcs0 
\insrsid8660178\charrsid8660178 \hich\af31506\dbch\af31505\loch\f31506  feed }{\rtlch\fcs1 \af31507 \ltrch\fcs0 \insrsid8660178\charrsid8660178 \loch\af31506\hich\af31506\dbch\f31505 \'b5\'d8\'d6\'b7}{\rtlch\fcs1 \af31507 \ltrch\fcs0 
\insrsid8660178\charrsid8660178 \hich\af31506\dbch\af31505\loch\f31506 )
\par \hich\af31506\dbch\af31505\loch\f31506      * @param maxStaleSeconds }{\rtlch\fcs1 \af31507 \ltrch\fcs0 \insrsid8660178\charrsid8660178 \loch\af31506\hich\af31506\dbch\f31505 \'d4\'ca\'d0\'ed\'b5\'c4\'d7\'ee\'b4\'f3\'ca\'fd\'be\'dd\'b9\'fd\'ca\'b1\'ca\'b1
\'bc\'e4}{\rtlch\fcs1 \af31507 \ltrch\fcs0 \insrsid8660178\charrsid8660178 \hich\af31506\dbch\af31505\loch\f31506  (}{\rtlch\fcs1 \af31507 \ltrch\fcs0 \insrsid8660178\charrsid8660178 \loch\af31506\hich\af31506\dbch\f31505 \'c3\'eb}{\rtlch\fcs1 \af31507 
\ltrch\fcs0 \insrsid8660178\charrsid8660178 \hich\af31506\dbch\af31505\loch\f31506 )}{\rtlch\fcs1 \af31507 \ltrch\fcs0 \insrsid8660178\charrsid8660178 \loch\af31506\hich\af31506\dbch\f31505 \'a3\'ac\'d3\'c3\'d3\'da\'b7\'c0\'d6\'b9\'b6\'c1\'c8\'a1\'b9\'fd
\'c6\'da\'b5\'c4\'be\'c9\'bc\'db\'b8\'f1}{\rtlch\fcs1 \af31507 \ltrch\fcs0 \insrsid8660178\charrsid8660178 
\par \hich\af31506\dbch\af31505\loch\f31506      * @return }{\rtlch\fcs1 \af31507 \ltrch\fcs0 \insrsid8660178\charrsid8660178 \loch\af31506\hich\af31506\dbch\f31505 \'b1\'ea\'d7\'bc\'bb\'af\'ba\'f3\'b5\'c4\'bc\'db\'b8\'f1}{\rtlch\fcs1 \af31507 \ltrch\fcs0 
\insrsid8660178\charrsid8660178 \hich\af31506\dbch\af31505\loch\f31506  (uint256)
\par \hich\af31506\dbch\af31505\loch\f31506      */
\par \hich\af31506\dbch\af31505\loch\f31506     \hich\af31506\dbch\af31505\loch\f31506 function getPriceWad(address feed, uint256 maxStaleSeconds) internal view returns (uint256) \{
\par \hich\af31506\dbch\af31505\loch\f31506         // 1. }{\rtlch\fcs1 \af31507 \ltrch\fcs0 \insrsid8660178\charrsid8660178 \loch\af31506\hich\af31506\dbch\f31505 \'bc\'ec\'b2\'e9\'b5\'d8\'d6\'b7\'ca\'c7\'b7\'f1\'d3\'d0\'d0\'a7}{\rtlch\fcs1 \af31507 
\ltrch\fcs0 \insrsid8660178\charrsid8660178 
\par \hich\af31506\dbch\af31505\loch\f31506         if (feed == address(0)) revert OracleFeedNotSet();
\par 
\par \hich\af31506\dbch\af31505\loch\f31506         // 2. }{\rtlch\fcs1 \af31507 \ltrch\fcs0 \insrsid8660178\charrsid8660178 \loch\af31506\hich\af31506\dbch\f31505 \'ca\'b5\'c0\'fd\'bb\'af\'bd\'d3\'bf\'da}{\rtlch\fcs1 \af31507 \ltrch\fcs0 
\insrsid8660178\charrsid8660178 
\par \hich\af31506\dbch\af31505\loch\f31506         AggregatorV3Interface agg = AggregatorV3Interface(feed);
\par \hich\af31506\dbch\af31505\loch\f31506         
\par \hich\af31506\dbch\af31505\loch\f31506         // 3. }{\rtlch\fcs1 \af31507 \ltrch\fcs0 \insrsid8660178\charrsid8660178 \loch\af31506\hich\af31506\dbch\f31505 \'bb\'f1\'c8\'a1\'d7\'ee\'d0\'c2\'d2\'bb\'c2\'d6\'b5\'c4\'ca\'fd\'be\'dd}{\rtlch\fcs1 \af31507 
\ltrch\fcs0 \insrsid8660178\charrsid8660178 
\par \hich\af31506\dbch\af31505\loch\f31506         // }{\rtlch\fcs1 \af31507 \ltrch\fcs0 \insrsid8660178\charrsid8660178 \loch\af31506\hich\af31506\dbch\f31505 \'b7\'b5\'bb\'d8\'d6\'b5}{\rtlch\fcs1 \af31507 \ltrch\fcs0 \insrsid8660178\charrsid8660178 
\hich\af31506\dbch\af31505\loch\f31506 : roundId, answer(}{\rtlch\fcs1 \af31507 \ltrch\fcs0 \insrsid8660178\charrsid8660178 \loch\af31506\hich\af31506\dbch\f31505 \'bc\'db\'b8\'f1}{\rtlch\fcs1 \af31507 \ltrch\fcs0 \insrsid8660178\charrsid8660178 
\hich\af31506\dbch\af31505\loch\f31506 ), startedAt, updatedAt(}{\rtlch\fcs1 \af31507 \ltrch\fcs0 \insrsid8660178\charrsid8660178 \loch\af31506\hich\af31506\dbch\f31505 \'b8\'fc\'d0\'c2\'ca\'b1\'bc\'e4}{\rtlch\fcs1 \af31507 \ltrch\fcs0 
\insrsid8660178\charrsid8660178 \hich\af31506\dbch\af31505\loch\f31506 ), answeredInRound
\par \hich\af31506\dbch\af31505\loch\f31506         (, int256 answer, , uint256 updatedAt, ) = agg.latestRoundData();
\par 
\par \hich\af31506\dbch\af31505\loch\f31506         // 4. }{\rtlch\fcs1 \af31507 \ltrch\fcs0 \insrsid8660178\charrsid8660178 \loch\af31506\hich\af31506\dbch\f31505 \'d1\'e9\'d6\'a4\'bc\'db\'b8\'f1\'d3\'d0\'d0\'a7\'d0\'d4}{\rtlch\fcs1 \af31507 \ltrch\fcs0 
\insrsid8660178\charrsid8660178 
\par \hich\af31506\dbch\af31505\loch\f31506         // }{\rtlch\fcs1 \af31507 \ltrch\fcs0 \insrsid8660178\charrsid8660178 \loch\af31506\hich\af31506\dbch\f31505 \'bc\'db\'b8\'f1\'b1\'d8\'d0\'eb\'b4\'f3\'d3\'da}{\rtlch\fcs1 \af31507 \ltrch\fcs0 
\insrsid8660178\charrsid8660178 \hich\af31506\dbch\af31505\loch\f31506  0}{\rtlch\fcs1 \af31507 \ltrch\fcs0 \insrsid8660178\charrsid8660178 \loch\af31506\hich\af31506\dbch\f31505 \'a3\'ac\'b7\'f1\'d4\'f2\'cb\'b5\'c3\'f7\'ca\'fd\'be\'dd\'d4\'b4\'d3\'d0
\'ce\'ca\'cc\'e2}{\rtlch\fcs1 \af31507 \ltrch\fcs0 \insrsid8660178\charrsid8660178 
\par \hich\af31506\dbch\af31505\loch\f31506         if (answer <= 0) revert OraclePriceInvalid();
\par \hich\af31506\dbch\af31505\loch\f31506         
\par \hich\af31506\dbch\af31505\loch\f31506         // 5. }{\rtlch\fcs1 \af31507 \ltrch\fcs0 \insrsid8660178\charrsid8660178 \loch\af31506\hich\af31506\dbch\f31505 \'d1\'e9\'d6\'a4\'ca\'fd\'be\'dd\'d0\'c2\'cf\'ca\'b6\'c8}{\rtlch\fcs1 \af31507 \ltrch\fcs0 
\insrsid8660178\charrsid8660178 
\par \hich\af31506\dbch\af31505\loch\f31506         // }{\rtlch\fcs1 \af31507 \ltrch\fcs0 \insrsid8660178\charrsid8660178 \loch\af31506\hich\af31506\dbch\f31505 \'c8\'e7\'b9\'fb\'b8\'fc\'d0\'c2\'ca\'b1\'bc\'e4\'ce\'aa}{\rtlch\fcs1 \af31507 \ltrch\fcs0 
\insrsid8660178\charrsid8660178 0}{\rtlch\fcs1 \af31507 \ltrch\fcs0 \insrsid8660178\charrsid8660178 \loch\af31506\hich\af31506\dbch\f31505 \'a3\'ac\'bb\'f2\'d5\'df\'b5\'b1\'c7\'b0\'ca\'b1\'bc\'e4}{\rtlch\fcs1 \af31507 \ltrch\fcs0 
\insrsid8660178\charrsid8660178 \hich\af31506\dbch\af31505\loch\f31506  - }{\rtlch\fcs1 \af31507 \ltrch\fcs0 \insrsid8660178\charrsid8660178 \loch\af31506\hich\af31506\dbch\f31505 \'b8\'fc\'d0\'c2\'ca\'b1\'bc\'e4}{\rtlch\fcs1 \af31507 \ltrch\fcs0 
\insrsid8660178\charrsid8660178 \hich\af31506\dbch\af31505\loch\f31506  > }{\rtlch\fcs1 \af31507 \ltrch\fcs0 \insrsid8660178\charrsid8660178 \loch\af31506\hich\af31506\dbch\f31505 \'d4\'ca\'d0\'ed\'b5\'c4\'d7\'ee\'b4\'f3\'ca\'b1\'bc\'e4\'a3\'ac\'cb\'b5
\'c3\'f7\'ca\'fd\'be\'dd\'cc\'ab\'be\'c9\'c1\'cb}{\rtlch\fcs1 \af31507 \ltrch\fcs0 \insrsid8660178\charrsid8660178 
\par \hich\af31506\dbch\af31505\loch\f31506         if (updatedAt == 0 || block.timestamp > updatedAt + maxStaleSeconds) revert OraclePriceStale();
\par 
\par \hich\af31506\dbch\af31505\loch\f31506         // 6. }{\rtlch\fcs1 \af31507 \ltrch\fcs0 \insrsid8660178\charrsid8660178 \loch\af31506\hich\af31506\dbch\f31505 \'be\'ab\'b6\'c8\'d7\'aa\'bb\'bb}{\rtlch\fcs1 \af31507 \ltrch\fcs0 
\insrsid8660178\charrsid8660178 \hich\af31506\dbch\af31505\loch\f31506  (}{\rtlch\fcs1 \af31507 \ltrch\fcs0 \insrsid8660178\charrsid8660178 \loch\af31506\hich\af31506\dbch\f31505 \'b1\'ea\'d7\'bc\'bb\'af\'b5\'bd}{\rtlch\fcs1 \af31507 \ltrch\fcs0 
\insrsid8660178\charrsid8660178 \hich\af31506\dbch\af31505\loch\f31506  18 }{\rtlch\fcs1 \af31507 \ltrch\fcs0 \insrsid8660178\charrsid8660178 \loch\af31506\hich\af31506\dbch\f31505 \'ce\'bb\'d0\'a1\'ca\'fd}{\rtlch\fcs1 \af31507 \ltrch\fcs0 
\insrsid8660178\charrsid8660178 \hich\af31506\dbch\af31505\loch\f31506 )
\par \hich\af31506\dbch\af31505\loch\f31506         // Chainlink }{\rtlch\fcs1 \af31507 \ltrch\fcs0 \insrsid8660178\charrsid8660178 \loch\af31506\hich\af31506\dbch\f31505 \'b5\'c4\'bc\'db\'b8\'f1\'be\'ab\'b6\'c8\'b2\'bb\'d2\'bb\'b6\'a8\'ca\'c7}{\rtlch\fcs1 
\af31507 \ltrch\fcs0 \insrsid8660178\charrsid8660178 \hich\af31506\dbch\af31505\loch\f31506  18 (}{\rtlch\fcs1 \af31507 \ltrch\fcs0 \insrsid8660178\charrsid8660178 \loch\af31506\hich\af31506\dbch\f31505 \'c0\'fd\'c8\'e7}{\rtlch\fcs1 \af31507 \ltrch\fcs0 
\insrsid8660178\charrsid8660178 \hich\af31506\dbch\af31505\loch\f31506  ETH/USD }{\rtlch\fcs1 \af31507 \ltrch\fcs0 \insrsid8660178\charrsid8660178 \loch\af31506\hich\af31506\dbch\f31505 \'cd\'a8\'b3\'a3\'ca\'c7}{\rtlch\fcs1 \af31507 \ltrch\fcs0 
\insrsid8660178\charrsid8660178 \hich\af31506\dbch\af31505\loch\f31506  8 }{\rtlch\fcs1 \af31507 \ltrch\fcs0 \insrsid8660178\charrsid8660178 \loch\af31506\hich\af31506\dbch\f31505 \'ce\'bb}{\rtlch\fcs1 \af31507 \ltrch\fcs0 \insrsid8660178\charrsid8660178 
\hich\af31506\dbch\af31505\loch\f31506 )}{\rtlch\fcs1 \af31507 \ltrch\fcs0 \insrsid8660178\charrsid8660178 \loch\af31506\hich\af31506\dbch\f31505 \'a3\'ac\'cb\'f9\'d2\'d4\'d0\'e8\'d2\'aa\'d7\'aa\'bb\'bb}{\rtlch\fcs1 \af31507 \ltrch\fcs0 
\insrsid8660178\charrsid8660178 
\par \hich\af31506\dbch\af31505\loch\f31506         uint8 priceDecimals = agg.decimals();
\par \hich\af31506\dbch\af31505\loch\f31506         uint256 p = uint256(answer);
\par 
\par \hich\af31506\dbch\af31505\loch\f31506         // }{\rtlch\fcs1 \af31507 \ltrch\fcs0 \insrsid8660178\charrsid8660178 \loch\af31506\hich\af31506\dbch\f31505 \'c8\'e7\'b9\'fb}{\rtlch\fcs1 \af31507 \ltrch\fcs0 \insrsid8660178\charrsid8660178 
\hich\af31506\dbch\af31505\loch\f31506  Chainlink }{\rtlch\fcs1 \af31507 \ltrch\fcs0 \insrsid8660178\charrsid8660178 \loch\af31506\hich\af31506\dbch\f31505 \'b1\'be\'c9\'ed\'be\'cd\'ca\'c7}{\rtlch\fcs1 \af31507 \ltrch\fcs0 \insrsid8660178\charrsid8660178 
\hich\af31506\dbch\af31505\loch\f31506  18 }{\rtlch\fcs1 \af31507 \ltrch\fcs0 \insrsid8660178\charrsid8660178 \loch\af31506\hich\af31506\dbch\f31505 \'ce\'bb\'a3\'ac\'d6\'b1\'bd\'d3\'b7\'b5\'bb\'d8}{\rtlch\fcs1 \af31507 \ltrch\fcs0 
\insrsid8660178\charrsid8660178 
\par \hich\af31506\dbch\af31505\loch\f31506         if (priceDecimals == 18) return p;
\par \hich\af31506\dbch\af31505\loch\f31506         
\par \hich\af31506\dbch\af31505\loch\f31506        \hich\af31506\dbch\af31505\loch\f31506  // }{\rtlch\fcs1 \af31507 \ltrch\fcs0 \insrsid8660178\charrsid8660178 \loch\af31506\hich\af31506\dbch\f31505 \'c8\'e7\'b9\'fb}{\rtlch\fcs1 \af31507 \ltrch\fcs0 
\insrsid8660178\charrsid8660178 \hich\af31506\dbch\af31505\loch\f31506  Chainlink }{\rtlch\fcs1 \af31507 \ltrch\fcs0 \insrsid8660178\charrsid8660178 \loch\af31506\hich\af31506\dbch\f31505 \'be\'ab\'b6\'c8\'d0\'a1\'d3\'da}{\rtlch\fcs1 \af31507 \ltrch\fcs0 
\insrsid8660178\charrsid8660178 \hich\af31506\dbch\af31505\loch\f31506  18 (}{\rtlch\fcs1 \af31507 \ltrch\fcs0 \insrsid8660178\charrsid8660178 \loch\af31506\hich\af31506\dbch\f31505 \'c0\'fd\'c8\'e7}{\rtlch\fcs1 \af31507 \ltrch\fcs0 
\insrsid8660178\charrsid8660178 \hich\af31506\dbch\af31505\loch\f31506  8 }{\rtlch\fcs1 \af31507 \ltrch\fcs0 \insrsid8660178\charrsid8660178 \loch\af31506\hich\af31506\dbch\f31505 \'ce\'bb}{\rtlch\fcs1 \af31507 \ltrch\fcs0 \insrsid8660178\charrsid8660178 
\hich\af31506\dbch\af31505\loch\f31506 )}{\rtlch\fcs1 \af31507 \ltrch\fcs0 \insrsid8660178\charrsid8660178 \loch\af31506\hich\af31506\dbch\f31505 \'a3\'ac\'d0\'e8\'d2\'aa\'b2\'b9\'c1\'e3\'b7\'c5\'b4\'f3}{\rtlch\fcs1 \af31507 \ltrch\fcs0 
\insrsid8660178\charrsid8660178 
\par \hich\af31506\dbch\af31505\loch\f31506         if (priceDecimals < 18) return p * (10 ** (18 - priceDecimals));
\par \hich\af31506\dbch\af31505\loch\f31506         
\par \hich\af31506\dbch\af31505\loch\f31506         // }{\rtlch\fcs1 \af31507 \ltrch\fcs0 \insrsid8660178\charrsid8660178 \loch\af31506\hich\af31506\dbch\f31505 \'c8\'e7\'b9\'fb}{\rtlch\fcs1 \af31507 \ltrch\fcs0 \insrsid8660178\charrsid8660178 
\hich\af31506\dbch\af31505\loch\f31506  Chainlink }{\rtlch\fcs1 \af31507 \ltrch\fcs0 \insrsid8660178\charrsid8660178 \loch\af31506\hich\af31506\dbch\f31505 \'be\'ab\'b6\'c8\'b4\'f3\'d3\'da}{\rtlch\fcs1 \af31507 \ltrch\fcs0 \insrsid8660178\charrsid8660178 
\hich\af31506\dbch\af31505\loch\f31506  18 (}{\rtlch\fcs1 \af31507 \ltrch\fcs0 \insrsid8660178\charrsid8660178 \loch\af31506\hich\af31506\dbch\f31505 \'bc\'ab\'c9\'d9\'bc\'fb}{\rtlch\fcs1 \af31507 \ltrch\fcs0 \insrsid8660178\charrsid8660178 
\hich\af31506\dbch\af31505\loch\f31506 )}{\rtlch\fcs1 \af31507 \ltrch\fcs0 \insrsid8660178\charrsid8660178 \loch\af31506\hich\af31506\dbch\f31505 \'a3\'ac\'d0\'e8\'d2\'aa\'bd\'d8\'b6\'cf\'cb\'f5\'d0\'a1}{\rtlch\fcs1 \af31507 \ltrch\fcs0 
\insrsid8660178\charrsid8660178 
\par \hich\af31506\dbch\af31505\loch\f31506         return p / (10 ** (priceDecimals - 18));
\par \hich\af31506\dbch\af31505\loch\f31506     \}
\par \}}{\rtlch\fcs1 \af31507 \ltrch\fcs0 \insrsid15750930 
\par }{\*\themedata 504b030414000600080000002100e9de0fbfff0000001c020000130000005b436f6e74656e745f54797065735d2e786d6cac91cb4ec3301045f748fc83e52d4a
9cb2400825e982c78ec7a27cc0c8992416c9d8b2a755fbf74cd25442a820166c2cd933f79e3be372bd1f07b5c3989ca74aaff2422b24eb1b475da5df374fd9ad
5689811a183c61a50f98f4babebc2837878049899a52a57be670674cb23d8e90721f90a4d2fa3802cb35762680fd800ecd7551dc18eb899138e3c943d7e503b6
b01d583deee5f99824e290b4ba3f364eac4a430883b3c092d4eca8f946c916422ecab927f52ea42b89a1cd59c254f919b0e85e6535d135a8de20f20b8c12c3b0
0c895fcf6720192de6bf3b9e89ecdbd6596cbcdd8eb28e7c365ecc4ec1ff1460f53fe813d3cc7f5b7f020000ffff0300504b030414000600080000002100a5d6
a7e7c0000000360100000b0000005f72656c732f2e72656c73848fcf6ac3300c87ef85bd83d17d51d2c31825762fa590432fa37d00e1287f68221bdb1bebdb4f
c7060abb0884a4eff7a93dfeae8bf9e194e720169aaa06c3e2433fcb68e1763dbf7f82c985a4a725085b787086a37bdbb55fbc50d1a33ccd311ba548b6309512
0f88d94fbc52ae4264d1c910d24a45db3462247fa791715fd71f989e19e0364cd3f51652d73760ae8fa8c9ffb3c330cc9e4fc17faf2ce545046e37944c69e462
a1a82fe353bd90a865aad41ed0b5b8f9d6fd010000ffff0300504b0304140006000800000021006b799616830000008a0000001c0000007468656d652f746865
6d652f7468656d654d616e616765722e786d6c0ccc4d0ac3201040e17da17790d93763bb284562b2cbaebbf600439c1a41c7a0d29fdbd7e5e38337cedf14d59b
4b0d592c9c070d8a65cd2e88b7f07c2ca71ba8da481cc52c6ce1c715e6e97818c9b48d13df49c873517d23d59085adb5dd20d6b52bd521ef2cdd5eb9246a3d8b
4757e8d3f729e245eb2b260a0238fd010000ffff0300504b0304140006000800000021003a05cc19a2070000ce200000160000007468656d652f7468656d652f
7468656d65312e786d6cec59dd8b1b47127f3fc8ff30ccbbacaf197d2c96833ebdb1776d63c93ef2d82bb534eded9916ddad5d8b6008ce5308040249c84302e1
5eee21840b5ce04ceee1fe97f36193cbfd1157dd339ae9965af1eee20373eceeb2687a7e55fdebaaeaaa52f7cdf79fc6d43bc35c109674fcea8d8aefe164ca66
245974fc479351a9e57b42a26486284b70c75f63e1bf7febbd3fdc440732c231f6403e1107a8e347522e0fca65318561246eb0254ee0dd9cf1184978e48bf28c
a373d01bd372ad526994634412df4b500c6aefcfe7648abd7fbdf8fbaf7ffae69f1f7f067ffeadcd1c430a132552a88129e5633503b6043576765a5508b1167d
cabd33443b3e4c3763e713fc54fa1e4542c28b8e5fd13f7ef9d6cd323ac884a8dc236bc88df44f269709cc4e6b7a4ebe38c9270d8230687473fd1a40e52e6ed8
1c36868d5c9f06a0e914569a72b175366bfd20c31aa0f4a343f7a039a8572dbca1bfbec3b91baa5f0baf41a9fe60073f1af5c18a165e83527cb8830f7beddec0
d6af4129beb1836f56ba83a069e9d7a08892e474075d091bf5fe66b53964cee8a113de0e8351b396292f50100d7974a929e62c91fb622d464f181f0140012992
24f1e47a89e7680ac1fcfac74f5ffff20fef882c2288bb254a9880d14aad32aad4e1bffa0df427ed5074809121ac680111b133a4e87862cac95276fc3ba0d537
20af5ebc78f9fce797cffff6f2934f5e3eff4b36b75665c91da26461cafdf6e72ffef3ddc7debffffafd6f5f7e954ebd8d1726de5a9a533dacb8b0c4abaf7f7a
fdf34fafbef9fcd71fbe7468ef727462c22724c6c2bb87cfbd872c86053a26c027fc721293081153a29b2c044a909ac5a17f28230b7d6f8d2872e07ad8b6e363
0e99c605bcbd7a62111e477c258943e3dd28b680c78cd11ee34e2bdc557319669eac92857b72be32710f113a73cddd4789e5e5e16a092996b854f6236cd17c40
5122d10227587aea1d3bc5d8b1ba0f09b1ec7a4ca69c093697de87c4eb21e234c9849c58d154081d9218fcb27611047f5bb6397eecf51875ad7a80cf6c24ec0d
441de427985a66bc8d5612c52e95131453d3e04748462e92e3359f9ab8a190e0e905a6cc1bceb0102e99fb1cd66b38fd2e82e4e674fb315dc736924b72ead279
841833910376da8f50bc7461c724894cec07e2144214790f9874c18f99bd43d433f801257bddfd9860cbdd6fce068f20c39a948a00516f56dce1cbdb9859f13b
5ed339c2ae54d3e5b19562bb9c38a3a3b75a58a17d843145e76886b1f7e80307831e5b5a362f48df8920ab1c625760dd4176acaae7040bece9de66374f1e1161
85ec182fd81e3ec7ebadc4b346498cf83ecdf7c0eba6cd87271c36a3639df7e9f4d404de23d00942bc388d725f800e23b8f76a7d1021ab80a967e18ed735b7fc
77913d06fbf28945e302fb1264f0a56520b19b32bf6b9b09a2d60445c04c10f18e5ce916442cf71722aab86ab195536e6e6fdac20dd01c593d4f4c923735405b
ad4ff8bf6b7da0c178f5ed778e187c3bed8e5bb195ab2ed9e8eccb25875bedcd3edc7653d3677c46defd9e668056c9030c656437615db734d72d8dff7fdfd2ec
dbcfd78dccbe76e3ba91f1a1c1b86e64b2a395b7d3c814bd0bb435eabc233de6d1873ef1de339f39a1742cd7141f097dec23e0ebcc6c04834a4e1f7be2fc0c70
19c14755e660020bb7e048cb789cc93f12198d23b484c3a1aaaf942c44a67a21bc25137066a4879dba159eaee263364b8f3aab5575ac9956568164315e09f371
38a69229bad12c8eef72f59aed421fb36e0828d9cb903026b349d41d249a9b4165247da80b467390d02b7b2b2cda0e162da57ee3aa1d16402df70a7cdff6e05b
7ac70f03100121388e83de7ca6fc94ba7ae35dedccb7e9e97dc6b422001aec4d04149e6e2bae7b97a7569786da053c6d9130c2cd26a12da31b3c11c1b7e02c3a
d5e845685cd6d7edc2a5163d650a3d1f845641a3d9fa3d1657f535c86de7069a98998226de79c76fd4430899295a76fc391c19c3c77809b123d4572e441770fd
32953cddf057c92c4b2ee400892835b84e3a69368889c4dca324eef86af9b91b68a27388e656ad41427867c9b521adbc6be4c0e9b693f17c8ea7d274bb31a22c
9d3e42864f7385f3ad16bf3a5849b215b87b1ccdcebd13bae20f118458d8ac2a03ce8880ab836a6acd1981abb03c9115f1b75598b2b46bde45e9184ac7115d46
28ab2866324fe13a95e774f4536e03e3295b3318d4304956084f16aac09a46b5aa695e35520e7babee9b8594e58ca459d44c2baba8aae9ce62d60c9b32b065cb
ab157983d5c6c490d3cc0a9fa6eeed94dbdee4baad3e21af1260f0dc7e8eaa7b818260502b26b3a829c6bb6958e5ec6cd4ae1d9b05be81da458a8491f51b1bb5
5b76cb6b84733a18bc52e507b9eda885a1f9a6afd496d657e7e6b5363b7902c963005dee8a4aa15d0997d61c414334d63d499a36608b3c95d9d6804fde8a938e
ff5125ec06fd5ad82f555ae1b014d4834aa91576eba56e18d6abc3b05a19f46acfa0b0c828ae86e9b5fd08ee2fe83abbbcd7e33b17f8f1e68ae6c694c565a62f
e8cb9ab8bec0afd65c17f8137535ef7b0492ce478ddaa85d6ff71aa576bd3b2a05835eabd4ee377aa541a3df1c8c06fdb0d51e3df3bd330d0ebaf57ed018b64a
8d6abf5f0a1a1545bfd52e35835aad1b34bbad61d07d96b531b0f2347d64b600f36a5eb7fe0b0000ffff0300504b0304140006000800000021000dd1909fb600
00001b010000270000007468656d652f7468656d652f5f72656c732f7468656d654d616e616765722e786d6c2e72656c73848f4d0ac2301484f78277086f6fd3
ba109126dd88d0add40384e4350d363f2451eced0dae2c082e8761be9969bb979dc9136332de3168aa1a083ae995719ac16db8ec8e4052164e89d93b64b06082
8e6f37ed1567914b284d262452282e3198720e274a939cd08a54f980ae38a38f56e422a3a641c8bbd048f7757da0f19b017cc524bd62107bd5001996509affb3
fd381a89672f1f165dfe514173d9850528a2c6cce0239baa4c04ca5bbabac4df000000ffff0300504b01022d0014000600080000002100e9de0fbfff0000001c
0200001300000000000000000000000000000000005b436f6e74656e745f54797065735d2e786d6c504b01022d0014000600080000002100a5d6a7e7c0000000
360100000b00000000000000000000000000300100005f72656c732f2e72656c73504b01022d00140006000800000021006b799616830000008a0000001c0000
0000000000000000000000190200007468656d652f7468656d652f7468656d654d616e616765722e786d6c504b01022d00140006000800000021003a05cc19a2
070000ce2000001600000000000000000000000000d60200007468656d652f7468656d652f7468656d65312e786d6c504b01022d00140006000800000021000d
d1909fb60000001b0100002700000000000000000000000000ac0a00007468656d652f7468656d652f5f72656c732f7468656d654d616e616765722e786d6c2e72656c73504b050600000000050005005d010000a70b00000000}
{\*\colorschememapping 3c3f786d6c2076657273696f6e3d22312e302220656e636f64696e673d225554462d3822207374616e64616c6f6e653d22796573223f3e0d0a3c613a636c724d
617020786d6c6e733a613d22687474703a2f2f736368656d61732e6f70656e786d6c666f726d6174732e6f72672f64726177696e676d6c2f323030362f6d6169
6e22206267313d226c743122207478313d22646b3122206267323d226c743222207478323d22646b322220616363656e74313d22616363656e74312220616363
656e74323d22616363656e74322220616363656e74333d22616363656e74332220616363656e74343d22616363656e74342220616363656e74353d22616363656e74352220616363656e74363d22616363656e74362220686c696e6b3d22686c696e6b2220666f6c486c696e6b3d22666f6c486c696e6b222f3e}
{\*\latentstyles\lsdstimax376\lsdlockeddef0\lsdsemihiddendef0\lsdunhideuseddef0\lsdqformatdef0\lsdprioritydef99{\lsdlockedexcept \lsdqformat1 \lsdpriority0 \lsdlocked0 Normal;\lsdqformat1 \lsdpriority9 \lsdlocked0 heading 1;
\lsdsemihidden1 \lsdunhideused1 \lsdqformat1 \lsdpriority9 \lsdlocked0 heading 2;\lsdsemihidden1 \lsdunhideused1 \lsdqformat1 \lsdpriority9 \lsdlocked0 heading 3;\lsdsemihidden1 \lsdunhideused1 \lsdqformat1 \lsdpriority9 \lsdlocked0 heading 4;
\lsdsemihidden1 \lsdunhideused1 \lsdqformat1 \lsdpriority9 \lsdlocked0 heading 5;\lsdsemihidden1 \lsdunhideused1 \lsdqformat1 \lsdpriority9 \lsdlocked0 heading 6;\lsdsemihidden1 \lsdunhideused1 \lsdqformat1 \lsdpriority9 \lsdlocked0 heading 7;
\lsdsemihidden1 \lsdunhideused1 \lsdqformat1 \lsdpriority9 \lsdlocked0 heading 8;\lsdsemihidden1 \lsdunhideused1 \lsdqformat1 \lsdpriority9 \lsdlocked0 heading 9;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 index 1;
\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 index 2;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 index 3;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 index 4;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 index 5;
\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 index 6;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 index 7;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 index 8;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 index 9;
\lsdsemihidden1 \lsdunhideused1 \lsdpriority39 \lsdlocked0 toc 1;\lsdsemihidden1 \lsdunhideused1 \lsdpriority39 \lsdlocked0 toc 2;\lsdsemihidden1 \lsdunhideused1 \lsdpriority39 \lsdlocked0 toc 3;
\lsdsemihidden1 \lsdunhideused1 \lsdpriority39 \lsdlocked0 toc 4;\lsdsemihidden1 \lsdunhideused1 \lsdpriority39 \lsdlocked0 toc 5;\lsdsemihidden1 \lsdunhideused1 \lsdpriority39 \lsdlocked0 toc 6;
\lsdsemihidden1 \lsdunhideused1 \lsdpriority39 \lsdlocked0 toc 7;\lsdsemihidden1 \lsdunhideused1 \lsdpriority39 \lsdlocked0 toc 8;\lsdsemihidden1 \lsdunhideused1 \lsdpriority39 \lsdlocked0 toc 9;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 Normal Indent;
\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 footnote text;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 annotation text;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 header;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 footer;
\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 index heading;\lsdsemihidden1 \lsdunhideused1 \lsdqformat1 \lsdpriority35 \lsdlocked0 caption;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 table of figures;
\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 envelope address;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 envelope return;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 footnote reference;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 annotation reference;
\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 line number;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 page number;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 endnote reference;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 endnote text;
\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 table of authorities;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 macro;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 toa heading;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 List;
\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 List Bullet;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 List Number;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 List 2;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 List 3;
\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 List 4;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 List 5;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 List Bullet 2;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 List Bullet 3;
\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 List Bullet 4;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 List Bullet 5;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 List Number 2;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 List Number 3;
\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 List Number 4;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 List Number 5;\lsdqformat1 \lsdpriority10 \lsdlocked0 Title;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 Closing;
\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 Signature;\lsdsemihidden1 \lsdunhideused1 \lsdpriority1 \lsdlocked0 Default Paragraph Font;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 Body Text;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 Body Text Indent;
\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 List Continue;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 List Continue 2;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 List Continue 3;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 List Continue 4;
\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 List Continue 5;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 Message Header;\lsdqformat1 \lsdpriority11 \lsdlocked0 Subtitle;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 Salutation;
\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 Date;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 Body Text First Indent;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 Body Text First Indent 2;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 Note Heading;
\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 Body Text 2;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 Body Text 3;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 Body Text Indent 2;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 Body Text Indent 3;
\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 Block Text;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 Hyperlink;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 FollowedHyperlink;\lsdqformat1 \lsdpriority22 \lsdlocked0 Strong;
\lsdqformat1 \lsdpriority20 \lsdlocked0 Emphasis;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 Document Map;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 Plain Text;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 E-mail Signature;
\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 HTML Top of Form;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 HTML Bottom of Form;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 Normal (Web);\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 HTML Acronym;
\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 HTML Address;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 HTML Cite;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 HTML Code;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 HTML Definition;
\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 HTML Keyboard;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 HTML Preformatted;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 HTML Sample;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 HTML Typewriter;
\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 HTML Variable;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 Normal Table;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 annotation subject;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 No List;
\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 Outline List 1;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 Outline List 2;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 Outline List 3;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 Table Simple 1;
\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 Table Simple 2;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 Table Simple 3;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 Table Classic 1;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 Table Classic 2;
\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 Table Classic 3;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 Table Classic 4;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 Table Colorful 1;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 Table Colorful 2;
\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 Table Colorful 3;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 Table Columns 1;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 Table Columns 2;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 Table Columns 3;
\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 Table Columns 4;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 Table Columns 5;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 Table Grid 1;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 Table Grid 2;
\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 Table Grid 3;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 Table Grid 4;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 Table Grid 5;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 Table Grid 6;
\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 Table Grid 7;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 Table Grid 8;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 Table List 1;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 Table List 2;
\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 Table List 3;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 Table List 4;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 Table List 5;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 Table List 6;
\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 Table List 7;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 Table List 8;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 Table 3D effects 1;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 Table 3D effects 2;
\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 Table 3D effects 3;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 Table Contemporary;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 Table Elegant;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 Table Professional;
\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 Table Subtle 1;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 Table Subtle 2;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 Table Web 1;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 Table Web 2;
\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 Table Web 3;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 Balloon Text;\lsdpriority39 \lsdlocked0 Table Grid;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 Table Theme;\lsdsemihidden1 \lsdlocked0 Placeholder Text;
\lsdqformat1 \lsdpriority1 \lsdlocked0 No Spacing;\lsdpriority60 \lsdlocked0 Light Shading;\lsdpriority61 \lsdlocked0 Light List;\lsdpriority62 \lsdlocked0 Light Grid;\lsdpriority63 \lsdlocked0 Medium Shading 1;\lsdpriority64 \lsdlocked0 Medium Shading 2;
\lsdpriority65 \lsdlocked0 Medium List 1;\lsdpriority66 \lsdlocked0 Medium List 2;\lsdpriority67 \lsdlocked0 Medium Grid 1;\lsdpriority68 \lsdlocked0 Medium Grid 2;\lsdpriority69 \lsdlocked0 Medium Grid 3;\lsdpriority70 \lsdlocked0 Dark List;
\lsdpriority71 \lsdlocked0 Colorful Shading;\lsdpriority72 \lsdlocked0 Colorful List;\lsdpriority73 \lsdlocked0 Colorful Grid;\lsdpriority60 \lsdlocked0 Light Shading Accent 1;\lsdpriority61 \lsdlocked0 Light List Accent 1;
\lsdpriority62 \lsdlocked0 Light Grid Accent 1;\lsdpriority63 \lsdlocked0 Medium Shading 1 Accent 1;\lsdpriority64 \lsdlocked0 Medium Shading 2 Accent 1;\lsdpriority65 \lsdlocked0 Medium List 1 Accent 1;\lsdsemihidden1 \lsdlocked0 Revision;
\lsdqformat1 \lsdpriority34 \lsdlocked0 List Paragraph;\lsdqformat1 \lsdpriority29 \lsdlocked0 Quote;\lsdqformat1 \lsdpriority30 \lsdlocked0 Intense Quote;\lsdpriority66 \lsdlocked0 Medium List 2 Accent 1;\lsdpriority67 \lsdlocked0 Medium Grid 1 Accent 1;
\lsdpriority68 \lsdlocked0 Medium Grid 2 Accent 1;\lsdpriority69 \lsdlocked0 Medium Grid 3 Accent 1;\lsdpriority70 \lsdlocked0 Dark List Accent 1;\lsdpriority71 \lsdlocked0 Colorful Shading Accent 1;\lsdpriority72 \lsdlocked0 Colorful List Accent 1;
\lsdpriority73 \lsdlocked0 Colorful Grid Accent 1;\lsdpriority60 \lsdlocked0 Light Shading Accent 2;\lsdpriority61 \lsdlocked0 Light List Accent 2;\lsdpriority62 \lsdlocked0 Light Grid Accent 2;\lsdpriority63 \lsdlocked0 Medium Shading 1 Accent 2;
\lsdpriority64 \lsdlocked0 Medium Shading 2 Accent 2;\lsdpriority65 \lsdlocked0 Medium List 1 Accent 2;\lsdpriority66 \lsdlocked0 Medium List 2 Accent 2;\lsdpriority67 \lsdlocked0 Medium Grid 1 Accent 2;\lsdpriority68 \lsdlocked0 Medium Grid 2 Accent 2;
\lsdpriority69 \lsdlocked0 Medium Grid 3 Accent 2;\lsdpriority70 \lsdlocked0 Dark List Accent 2;\lsdpriority71 \lsdlocked0 Colorful Shading Accent 2;\lsdpriority72 \lsdlocked0 Colorful List Accent 2;\lsdpriority73 \lsdlocked0 Colorful Grid Accent 2;
\lsdpriority60 \lsdlocked0 Light Shading Accent 3;\lsdpriority61 \lsdlocked0 Light List Accent 3;\lsdpriority62 \lsdlocked0 Light Grid Accent 3;\lsdpriority63 \lsdlocked0 Medium Shading 1 Accent 3;\lsdpriority64 \lsdlocked0 Medium Shading 2 Accent 3;
\lsdpriority65 \lsdlocked0 Medium List 1 Accent 3;\lsdpriority66 \lsdlocked0 Medium List 2 Accent 3;\lsdpriority67 \lsdlocked0 Medium Grid 1 Accent 3;\lsdpriority68 \lsdlocked0 Medium Grid 2 Accent 3;\lsdpriority69 \lsdlocked0 Medium Grid 3 Accent 3;
\lsdpriority70 \lsdlocked0 Dark List Accent 3;\lsdpriority71 \lsdlocked0 Colorful Shading Accent 3;\lsdpriority72 \lsdlocked0 Colorful List Accent 3;\lsdpriority73 \lsdlocked0 Colorful Grid Accent 3;\lsdpriority60 \lsdlocked0 Light Shading Accent 4;
\lsdpriority61 \lsdlocked0 Light List Accent 4;\lsdpriority62 \lsdlocked0 Light Grid Accent 4;\lsdpriority63 \lsdlocked0 Medium Shading 1 Accent 4;\lsdpriority64 \lsdlocked0 Medium Shading 2 Accent 4;\lsdpriority65 \lsdlocked0 Medium List 1 Accent 4;
\lsdpriority66 \lsdlocked0 Medium List 2 Accent 4;\lsdpriority67 \lsdlocked0 Medium Grid 1 Accent 4;\lsdpriority68 \lsdlocked0 Medium Grid 2 Accent 4;\lsdpriority69 \lsdlocked0 Medium Grid 3 Accent 4;\lsdpriority70 \lsdlocked0 Dark List Accent 4;
\lsdpriority71 \lsdlocked0 Colorful Shading Accent 4;\lsdpriority72 \lsdlocked0 Colorful List Accent 4;\lsdpriority73 \lsdlocked0 Colorful Grid Accent 4;\lsdpriority60 \lsdlocked0 Light Shading Accent 5;\lsdpriority61 \lsdlocked0 Light List Accent 5;
\lsdpriority62 \lsdlocked0 Light Grid Accent 5;\lsdpriority63 \lsdlocked0 Medium Shading 1 Accent 5;\lsdpriority64 \lsdlocked0 Medium Shading 2 Accent 5;\lsdpriority65 \lsdlocked0 Medium List 1 Accent 5;\lsdpriority66 \lsdlocked0 Medium List 2 Accent 5;
\lsdpriority67 \lsdlocked0 Medium Grid 1 Accent 5;\lsdpriority68 \lsdlocked0 Medium Grid 2 Accent 5;\lsdpriority69 \lsdlocked0 Medium Grid 3 Accent 5;\lsdpriority70 \lsdlocked0 Dark List Accent 5;\lsdpriority71 \lsdlocked0 Colorful Shading Accent 5;
\lsdpriority72 \lsdlocked0 Colorful List Accent 5;\lsdpriority73 \lsdlocked0 Colorful Grid Accent 5;\lsdpriority60 \lsdlocked0 Light Shading Accent 6;\lsdpriority61 \lsdlocked0 Light List Accent 6;\lsdpriority62 \lsdlocked0 Light Grid Accent 6;
\lsdpriority63 \lsdlocked0 Medium Shading 1 Accent 6;\lsdpriority64 \lsdlocked0 Medium Shading 2 Accent 6;\lsdpriority65 \lsdlocked0 Medium List 1 Accent 6;\lsdpriority66 \lsdlocked0 Medium List 2 Accent 6;
\lsdpriority67 \lsdlocked0 Medium Grid 1 Accent 6;\lsdpriority68 \lsdlocked0 Medium Grid 2 Accent 6;\lsdpriority69 \lsdlocked0 Medium Grid 3 Accent 6;\lsdpriority70 \lsdlocked0 Dark List Accent 6;\lsdpriority71 \lsdlocked0 Colorful Shading Accent 6;
\lsdpriority72 \lsdlocked0 Colorful List Accent 6;\lsdpriority73 \lsdlocked0 Colorful Grid Accent 6;\lsdqformat1 \lsdpriority19 \lsdlocked0 Subtle Emphasis;\lsdqformat1 \lsdpriority21 \lsdlocked0 Intense Emphasis;
\lsdqformat1 \lsdpriority31 \lsdlocked0 Subtle Reference;\lsdqformat1 \lsdpriority32 \lsdlocked0 Intense Reference;\lsdqformat1 \lsdpriority33 \lsdlocked0 Book Title;\lsdsemihidden1 \lsdunhideused1 \lsdpriority37 \lsdlocked0 Bibliography;
\lsdsemihidden1 \lsdunhideused1 \lsdqformat1 \lsdpriority39 \lsdlocked0 TOC Heading;\lsdpriority41 \lsdlocked0 Plain Table 1;\lsdpriority42 \lsdlocked0 Plain Table 2;\lsdpriority43 \lsdlocked0 Plain Table 3;\lsdpriority44 \lsdlocked0 Plain Table 4;
\lsdpriority45 \lsdlocked0 Plain Table 5;\lsdpriority40 \lsdlocked0 Grid Table Light;\lsdpriority46 \lsdlocked0 Grid Table 1 Light;\lsdpriority47 \lsdlocked0 Grid Table 2;\lsdpriority48 \lsdlocked0 Grid Table 3;\lsdpriority49 \lsdlocked0 Grid Table 4;
\lsdpriority50 \lsdlocked0 Grid Table 5 Dark;\lsdpriority51 \lsdlocked0 Grid Table 6 Colorful;\lsdpriority52 \lsdlocked0 Grid Table 7 Colorful;\lsdpriority46 \lsdlocked0 Grid Table 1 Light Accent 1;\lsdpriority47 \lsdlocked0 Grid Table 2 Accent 1;
\lsdpriority48 \lsdlocked0 Grid Table 3 Accent 1;\lsdpriority49 \lsdlocked0 Grid Table 4 Accent 1;\lsdpriority50 \lsdlocked0 Grid Table 5 Dark Accent 1;\lsdpriority51 \lsdlocked0 Grid Table 6 Colorful Accent 1;
\lsdpriority52 \lsdlocked0 Grid Table 7 Colorful Accent 1;\lsdpriority46 \lsdlocked0 Grid Table 1 Light Accent 2;\lsdpriority47 \lsdlocked0 Grid Table 2 Accent 2;\lsdpriority48 \lsdlocked0 Grid Table 3 Accent 2;
\lsdpriority49 \lsdlocked0 Grid Table 4 Accent 2;\lsdpriority50 \lsdlocked0 Grid Table 5 Dark Accent 2;\lsdpriority51 \lsdlocked0 Grid Table 6 Colorful Accent 2;\lsdpriority52 \lsdlocked0 Grid Table 7 Colorful Accent 2;
\lsdpriority46 \lsdlocked0 Grid Table 1 Light Accent 3;\lsdpriority47 \lsdlocked0 Grid Table 2 Accent 3;\lsdpriority48 \lsdlocked0 Grid Table 3 Accent 3;\lsdpriority49 \lsdlocked0 Grid Table 4 Accent 3;
\lsdpriority50 \lsdlocked0 Grid Table 5 Dark Accent 3;\lsdpriority51 \lsdlocked0 Grid Table 6 Colorful Accent 3;\lsdpriority52 \lsdlocked0 Grid Table 7 Colorful Accent 3;\lsdpriority46 \lsdlocked0 Grid Table 1 Light Accent 4;
\lsdpriority47 \lsdlocked0 Grid Table 2 Accent 4;\lsdpriority48 \lsdlocked0 Grid Table 3 Accent 4;\lsdpriority49 \lsdlocked0 Grid Table 4 Accent 4;\lsdpriority50 \lsdlocked0 Grid Table 5 Dark Accent 4;
\lsdpriority51 \lsdlocked0 Grid Table 6 Colorful Accent 4;\lsdpriority52 \lsdlocked0 Grid Table 7 Colorful Accent 4;\lsdpriority46 \lsdlocked0 Grid Table 1 Light Accent 5;\lsdpriority47 \lsdlocked0 Grid Table 2 Accent 5;
\lsdpriority48 \lsdlocked0 Grid Table 3 Accent 5;\lsdpriority49 \lsdlocked0 Grid Table 4 Accent 5;\lsdpriority50 \lsdlocked0 Grid Table 5 Dark Accent 5;\lsdpriority51 \lsdlocked0 Grid Table 6 Colorful Accent 5;
\lsdpriority52 \lsdlocked0 Grid Table 7 Colorful Accent 5;\lsdpriority46 \lsdlocked0 Grid Table 1 Light Accent 6;\lsdpriority47 \lsdlocked0 Grid Table 2 Accent 6;\lsdpriority48 \lsdlocked0 Grid Table 3 Accent 6;
\lsdpriority49 \lsdlocked0 Grid Table 4 Accent 6;\lsdpriority50 \lsdlocked0 Grid Table 5 Dark Accent 6;\lsdpriority51 \lsdlocked0 Grid Table 6 Colorful Accent 6;\lsdpriority52 \lsdlocked0 Grid Table 7 Colorful Accent 6;
\lsdpriority46 \lsdlocked0 List Table 1 Light;\lsdpriority47 \lsdlocked0 List Table 2;\lsdpriority48 \lsdlocked0 List Table 3;\lsdpriority49 \lsdlocked0 List Table 4;\lsdpriority50 \lsdlocked0 List Table 5 Dark;
\lsdpriority51 \lsdlocked0 List Table 6 Colorful;\lsdpriority52 \lsdlocked0 List Table 7 Colorful;\lsdpriority46 \lsdlocked0 List Table 1 Light Accent 1;\lsdpriority47 \lsdlocked0 List Table 2 Accent 1;\lsdpriority48 \lsdlocked0 List Table 3 Accent 1;
\lsdpriority49 \lsdlocked0 List Table 4 Accent 1;\lsdpriority50 \lsdlocked0 List Table 5 Dark Accent 1;\lsdpriority51 \lsdlocked0 List Table 6 Colorful Accent 1;\lsdpriority52 \lsdlocked0 List Table 7 Colorful Accent 1;
\lsdpriority46 \lsdlocked0 List Table 1 Light Accent 2;\lsdpriority47 \lsdlocked0 List Table 2 Accent 2;\lsdpriority48 \lsdlocked0 List Table 3 Accent 2;\lsdpriority49 \lsdlocked0 List Table 4 Accent 2;
\lsdpriority50 \lsdlocked0 List Table 5 Dark Accent 2;\lsdpriority51 \lsdlocked0 List Table 6 Colorful Accent 2;\lsdpriority52 \lsdlocked0 List Table 7 Colorful Accent 2;\lsdpriority46 \lsdlocked0 List Table 1 Light Accent 3;
\lsdpriority47 \lsdlocked0 List Table 2 Accent 3;\lsdpriority48 \lsdlocked0 List Table 3 Accent 3;\lsdpriority49 \lsdlocked0 List Table 4 Accent 3;\lsdpriority50 \lsdlocked0 List Table 5 Dark Accent 3;
\lsdpriority51 \lsdlocked0 List Table 6 Colorful Accent 3;\lsdpriority52 \lsdlocked0 List Table 7 Colorful Accent 3;\lsdpriority46 \lsdlocked0 List Table 1 Light Accent 4;\lsdpriority47 \lsdlocked0 List Table 2 Accent 4;
\lsdpriority48 \lsdlocked0 List Table 3 Accent 4;\lsdpriority49 \lsdlocked0 List Table 4 Accent 4;\lsdpriority50 \lsdlocked0 List Table 5 Dark Accent 4;\lsdpriority51 \lsdlocked0 List Table 6 Colorful Accent 4;
\lsdpriority52 \lsdlocked0 List Table 7 Colorful Accent 4;\lsdpriority46 \lsdlocked0 List Table 1 Light Accent 5;\lsdpriority47 \lsdlocked0 List Table 2 Accent 5;\lsdpriority48 \lsdlocked0 List Table 3 Accent 5;
\lsdpriority49 \lsdlocked0 List Table 4 Accent 5;\lsdpriority50 \lsdlocked0 List Table 5 Dark Accent 5;\lsdpriority51 \lsdlocked0 List Table 6 Colorful Accent 5;\lsdpriority52 \lsdlocked0 List Table 7 Colorful Accent 5;
\lsdpriority46 \lsdlocked0 List Table 1 Light Accent 6;\lsdpriority47 \lsdlocked0 List Table 2 Accent 6;\lsdpriority48 \lsdlocked0 List Table 3 Accent 6;\lsdpriority49 \lsdlocked0 List Table 4 Accent 6;
\lsdpriority50 \lsdlocked0 List Table 5 Dark Accent 6;\lsdpriority51 \lsdlocked0 List Table 6 Colorful Accent 6;\lsdpriority52 \lsdlocked0 List Table 7 Colorful Accent 6;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 Mention;
\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 Smart Hyperlink;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 Hashtag;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 Unresolved Mention;\lsdsemihidden1 \lsdunhideused1 \lsdlocked0 Smart Link;}}{\*\datastore 01050000
02000000180000004d73786d6c322e534158584d4c5265616465722e362e3000000000000000000000060000
d0cf11e0a1b11ae1000000000000000000000000000000003e000300feff090006000000000000000000000001000000010000000000000000100000feffffff00000000feffffff0000000000000000ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff
ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff
ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff
ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff
fffffffffffffffffdfffffffeffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff
ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff
ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff
ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff
ffffffffffffffffffffffffffffffff52006f006f007400200045006e00740072007900000000000000000000000000000000000000000000000000000000000000000000000000000000000000000016000500ffffffffffffffffffffffff0c6ad98892f1d411a65f0040963251e500000000000000000000000090e8
38a755d2dc01feffffff00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000ffffffffffffffffffffffff00000000000000000000000000000000000000000000000000000000
00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000ffffffffffffffffffffffff0000000000000000000000000000000000000000000000000000
000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000ffffffffffffffffffffffff000000000000000000000000000000000000000000000000
0000000000000000000000000000000000000000000000000105000000000000}}